"""import libraries"""
import numpy as np
import math
from scipy.integrate import odeint
import matplotlib.pyplot as plt
from tabulate import tabulate
from sklearn.metrics import mean_squared_error

"""create function, system of DE"""


# Функция составления и использования СДУ, файл с СДУ необходимо назвать "sdy.txt"


def f1(C, t):
    R, T = 8.314, 580
    # E1, E2, E3 = 12.444 * 10 ** 4, 14.897 * 10 ** 4, 14.1 * 10 ** 4
    E = []
    with open("E.txt") as f:
        for line_E in f:
            E.append(eval(line_E))
    # k01, k02, k03 = 3.225 * 10 ** 10, 5.220 * 10 ** 12, 4.999 * 10 ** 11
    k0 = []
    with open("k0.txt") as f:
        for line_k0 in f:
            k0.append(eval(line_k0))
    k = []
    for i in range(len(E)):
        k.append(k0[i] * math.exp(-E[i] / (R * T)))
    sdy = []
    product = []
    zamena_c = C
    zamena_K = k
    str_k = []
    for j in range(len(k)):
        str_k.append('k' + str(j+1))
    with open("sdy.txt") as f:
        for line in f:
            sdy.append(line[:-1])
    for i in range(len(sdy) - 1):
        product.append(sdy[-1][i])
    sdy = sdy[0:len(sdy) - 1]
    sdy_copy = sdy.copy()
    for m in range(len(sdy)):
        for n in range(len(product)):
            sdy_copy[m] = sdy_copy[m].replace(product[n], 'zamena_c[' + str(n) + ']')
        for v in range(len(k)):
            sdy_copy[m] = sdy_copy[m].replace(str_k[v], 'zamena_K[' + str(v) + ']')
    return [eval(sdy_copy[0]),
            eval(sdy_copy[1]),
            eval(sdy_copy[2]),
            eval(sdy_copy[3])]


def rungekutta4(f, y0, t):
    n = len(t)
    y = np.zeros((n, len(y0)))
    y[0] = y0
    for i in range(n - 1):
        h = t[i + 1] - t[i]
        K1 = f(y[i], t[i])
        K2 = f(y[i] + np.array(K1) * h / 2, t[i] + h / 2)
        K3 = f(y[i] + np.array(K2) * h / 2, t[i] + h / 2)
        K4 = f(y[i] + np.array(K3) * h, t[i] + h)
        y[i + 1] = y[i] + (h / 6) * (np.array(K1) + 2 * np.array(K2) + 2 * np.array(K3) + np.array(K4))
    return y


def plot_graphics(t, func, type):
    CA = func[:, 0]
    CB = func[:, 1]
    CC = func[:, 2]
    CD = func[:, 3]
    print(f"Концентрация продуктов в различные моменты времени по методу {type}")
    table = {"t": t, "CA(t)": CA, "CB(t)": CB, "CC(t)": CC, "CD(t)": CD}
    print(tabulate(table, headers="keys", tablefmt='fancy_grid', stralign='center'))
    fig = plt.figure(facecolor='white')
    plt.plot(t, CA, '-o', label='CA(t)', linewidth=2, markersize=3.5)
    plt.plot(t, CB, '-o', label='CB(t)', linewidth=2, markersize=3.5)
    plt.plot(t, CC, '-o', label='CC(t)', linewidth=2, markersize=3.5)
    plt.plot(t, CD, '-o', label='CD(t)', linewidth=2, markersize=3.5)
    plt.title(f"Кинетические кривые по методу {type}")
    plt.ylabel("C, моль/л")
    plt.xlabel("t, сек")
    plt.legend()
    plt.locator_params(axis='x', nbins=11)
    plt.grid(True)
    plt.show()  # display


def plot_graphics_comparsion(func1, func2, type):
    CA1 = func1[:, 0]
    CB1 = func1[:, 1]
    CC1 = func1[:, 2]
    CD1 = func1[:, 3]
    CA2 = func2[:, 0]
    CB2 = func2[:, 1]
    CC2 = func2[:, 2]
    CD2 = func2[:, 3]
    fig = plt.figure(facecolor='white')
    plt.plot(t, CA1, '-o', label='CA(t)_odeint', linewidth=2, markersize=2.5)
    plt.plot(t, CA2, '--', label='CA(t)_rkt4', linewidth=2, markersize=3.5)
    plt.plot(t, CB1, '-o', label='CB(t)_odeint', linewidth=2, markersize=2.5)
    plt.plot(t, CB2, '--', label='CC(t)_rkt4', linewidth=2, markersize=3.5)
    plt.plot(t, CC1, '-o', label='CC(t)_odeint', linewidth=2, markersize=2.5)
    plt.plot(t, CC2, '--', label='CC(t)_rkt4', linewidth=2, markersize=3.5)
    plt.plot(t, CD1, '-o', label='CD(t)_odeint', linewidth=2, markersize=2.5)
    plt.plot(t, CD2, '--', label='CD(t)_rkt4', linewidth=2, markersize=3.5)
    plt.title(f"Сравнение кинетических кривых по методам {type}")
    plt.ylabel("C, моль/л")
    plt.xlabel("t, сек")
    plt.legend()
    plt.locator_params(axis='x', nbins=11)
    plt.grid(True)
    plt.show()  # display


"""Model's parameters"""
print("Параметры модели")

#
# table = {"R": [R], "T": [T], "E1": [E1], "E2": [E2], "E3": [E3], "k01": [k01], "k02": [k02], "k03": [k03],
#          "k1": [k1], "k2": [k2], "k3": [k3]}
# print(tabulate(table, headers="keys", tablefmt='fancy_grid', stralign='center'))

"""Cauchy conditions"""
print("Начальные условия Коши")

# C = [0.3, 0, 0, 0.4]
C0 = []
with open("C0.txt") as f:
    for line_C in f:
        C0.append(eval(line_C))

# table = {"CA0": [CA0], "CB0": [CB0], "CC0": [CC0], "CD0": [CD0]}
# print(tabulate(table, headers="keys", tablefmt='fancy_grid', stralign='center'))

"""Decision odeint()"""

t = np.linspace(0, 10, 41)  # vector of time
w1 = odeint(f1, C0, t)  # solve eq.
plot_graphics(t, w1, "odeint()")

"""Decision Runge-Kutty"""

w2 = rungekutta4(f1, C0, t)
plot_graphics(t, w2, "Рунге-Кутты 4-го порядка")

"""Сomparison of methods"""

# plot_graphics_comparsion(w1, w2, "odeint и Рунге-Кутты 4-го порядка")
# mse = mean_squared_error(w1, w2)
# print("Mean Squared Error", mse)

